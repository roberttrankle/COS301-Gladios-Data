/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cos301.maven.data;

import javax.swing.JOptionPane;
import org.apache.sling.commons.json.JSONObject;

/**
 *
 * @author Data - Gladios
 */
public class Main {
    public static void main(String[] args) throws Exception {
        DataInterface data = new DataInterface();
        data.getInstance();
        //9C:5C:F9:3F:CD:8B
        JSONObject temp = new JSONObject();
        temp = data.getLocation("00:B3:62:4B:7C:42");
        String lol = temp.toString();
        JOptionPane.showMessageDialog(null, lol);
    }
}
