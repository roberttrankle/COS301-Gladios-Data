/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cos301.maven.data;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.html.*;
import java.net.URL;
import javax.xml.ws.Response;
import org.apache.log4j.BasicConfigurator;

/**
 * Aruba WebUI automated login and get location from HTTP WebResponse
 * @author ORATILE
 */


public class ClientLoginWeb {
        
      private String username;
      private String password;
      private WebClient webClient = null;
      private WebRequest request  = null;

     /**
     * Device current location in JSON format
     */
      WebResponse json_data_location = null;
      private HtmlTextInput usernameAruba;
      private HtmlPasswordInput passwordAruba;
      private final URL strURL;
      
      
     /**
     * Class constructor
     * @throws java.lang.Exception
     */
      public ClientLoginWeb(String MACaddress) throws Exception{
          
          webClient = new WebClient();
          webClient.getOptions().setUseInsecureSSL(true);
          username = "admin";
          password = "Aruba123!";
          //9C:5C:F9:3F:CD:8B
          String url = "https://137.215.6.208/api/v1/location?sta_eth_mac=" + MACaddress;
          strURL = new URL(url);
      }
      
     /**
     * Aruba WebUI login authentication
     * @throws java.lang.Exception
     */
      public void arubaLogin() throws Exception{
          
          HtmlPage arubaLoginPage = webClient.getPage("https://137.215.6.208");
          HtmlForm arubaLoginForm = arubaLoginPage.getHtmlElementById("login-form");
          
          HtmlSubmitInput btnLogin = arubaLoginForm.getInputByValue("Log In");
          usernameAruba = arubaLoginForm.getInputByName("j_username");
          passwordAruba = arubaLoginForm.getInputByName("j_password");
          
          usernameAruba.setValueAttribute(username);
          passwordAruba.setValueAttribute(password);
          
          HtmlPage homePage = btnLogin.click();
      }
      
     /**
     * Set WebClient HTTP request to Aruba WebUI
     */
      public void setRequest() {
          
         request = new WebRequest(strURL);
      }
      
     /**
     * Set WebClient HTTP response from Aruba WebUI
     * @throws java.lang.Exception
     */
      public void setResponse() throws Exception{
          
           json_data_location = webClient.loadWebResponse(request);
          
      }
      
     /**
     * Close WebClient connection
     */
      public void closeWebClient() {
          
          webClient.close();
      }      

    class json_datalocation {

        public json_datalocation() {
        }
    }
}