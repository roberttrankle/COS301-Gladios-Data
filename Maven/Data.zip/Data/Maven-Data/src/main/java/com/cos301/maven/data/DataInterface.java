package com.cos301.maven.data;

import org.apache.sling.commons.json.JSONObject;

/**THIS CLASS USES THE FOLLOWING CLASSES :
 * -Data
 * -ClientWebLogin
 * -URL
 * -JSONExtractor
*/

/**
 *
 * @author Gladios-Data module
 * @version beta
 */
public class DataInterface 
{
    private static Data instance = null;
    //instance of GIS -> supposed to be GISInterface
    //private GIS gis;

    /**
     * Default COnstructor for DataInterface
     */
    protected DataInterface()
    {
        
    }
    
    /**
     * Create a single instance of DataInterface class
     * @return instance of DataInterface
     */
    public static Data getInstance() throws Exception
    {
        if(instance == null)
        {
            instance = new Data();
        }
        return instance;
    }
    
    /**
     *
     * @param MACaddress The address of the device to be located.
     * @return JSON object with location
     */
    public JSONObject getLocation(String MACaddress) throws Exception
    {
        instance.getLocation(MACaddress);
        JSONObject obj = new JSONObject(instance.toString());
        return obj;  
    }

}