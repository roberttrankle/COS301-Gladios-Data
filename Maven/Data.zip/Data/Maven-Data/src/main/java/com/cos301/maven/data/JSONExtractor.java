
package com.cos301.maven.data;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.io.FileReader;
import java.io.BufferedReader;
/**
 *  A class to convert The string of data location, into longitude and latitude only.
 * @author Data-Gladious
 */
public class JSONExtractor {
    
    /**
     * The function to implement the extraction of data from the String
     * @param fileName String of data to convert.
     * @return A String with latitude and longitude.
     */
    public String Extract(String fileName)
    {
        String longi = "";
        String lati = "";
        String val = "none";
        try
        {
           {
               String line = fileName;
               
               if(line.contains("sta_location_x"))
                   longi = line.substring(line.indexOf("sta_location_x")+16,line.indexOf("sta_location_x")+25);
               if(line.contains("sta_location_y"))
                   lati = line.substring(line.indexOf("sta_location_y")+16,line.indexOf("sta_location_y")+25);
               
           }
           
            val = "\n{" +
                    "  \"Location\": {\n" +
                    "    \"Latitude\" : " + lati + ",\n" +
                    "    \"Longitude\": " + longi + "\n" +
                    "  }\n" +
                    "}";
        }
        
        catch(Exception e)
        {
            e.printStackTrace();
        }    
        return val;
    }
}
